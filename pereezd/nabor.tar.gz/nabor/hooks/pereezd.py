#!/usr/bin/env python3
"""Переезд из толстого чата (владелец: 15.11 – маяк и выжимка, 19.11 – «чат, с которого переезжаем, переименовывается на -»).

Хук UserPromptSubmit, модель не зовёт. Два случая:
1. В старом чате написали «переезд» (короткое сообщение) – подсказывает Claude порядок переезда
   и id этого чата: первой строкой выжимки «Старый чат: <id>».
2. В новом чате открыли выжимку (~/.claude/vyzhimki/<файл>.md в сообщении) – берёт из неё
   «Старый чат: <id>» и переименовывает тот чат в «-» (~/.claude/shablony/pereezd-pereimenovat.py).
   Переименовывает новый чат, а не старый: открытый чат дописывает своё название после каждого хода
   и затёр бы «-».
Скилл с порядком – ~/.claude/skills/pereezd/SKILL.md. Маяк порога – mayak-zhirnogo-chata.py.
Проверка: echo '{"prompt":"переезд","session_id":"x"}' | python3 этот_файл
"""
import json
import os
import re
import sys

sys.path.insert(0, os.path.expanduser('~/.claude/shablony'))

try:
    vhod = json.load(sys.stdin)
except Exception:
    sys.exit(0)
prompt = vhod.get('prompt') or ''
sid = vhod.get('session_id') or ''
koren = os.environ.get('PEREEZD_KOREN')  # только для проверки на копии


def skazat(tekst):
    print(json.dumps({'hookSpecificOutput': {'hookEventName': 'UserPromptSubmit', 'additionalContext': tekst}},
                     ensure_ascii=False))
    sys.exit(0)


# 2. Новый чат: «Продолжаем …: прочитай ~/.claude/vyzhimki/<файл>.md»
m = re.search(r'vyzhimki/([^\s/`«»"\']+\.md)', prompt)
if m:
    put = os.path.expanduser('~/.claude/vyzhimki/' + m.group(1))
    try:
        tekst = open(put, encoding='utf-8').read(4000)
    except OSError:
        sys.exit(0)
    s = re.search(r'Старый чат:\s*`?([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})', tekst)
    if not s or s.group(1) == sid:
        sys.exit(0)
    try:
        import importlib.util
        spec = importlib.util.spec_from_file_location('pp', os.path.expanduser('~/.claude/shablony/pereezd-pereimenovat.py'))
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        kod, itog = mod.pereimenovat(s.group(1), '-', koren or mod.KOREN)
    except Exception as e:
        kod, itog = 1, f'ошибка {e}'
    if kod == 0 and 'уже называется' in itog:
        sys.exit(0)
    skazat(f'ПЕРЕЕЗД: старый чат из выжимки переименован в «-» ({itog}). Скажи тебе об этом одной строкой в конце ответа.'
           if kod == 0 else
           f'ПЕРЕЕЗД: старый чат из выжимки переименовать в «-» не вышло ({itog}). Скажи тебе одной строкой: '
           f'переименовать вручную – /rename - в старом чате.')

# 1. Старый чат: «переезд», «переезжаем», «давай переедем» – короткой командой, а не в середине разговора о сайте
if len(prompt) <= 60 and re.search(r'переезд|переезжа|переед[её]м', prompt, re.I):
    skazat(
        f'ПЕРЕЕЗД (скилл pereezd). id этого чата: {sid}. Порядок: '
        '1) выжимка до 25 строк в ~/.claude/vyzhimki/<тема>-<дата ГГГГ-ММ-ДД>.md; ПЕРВАЯ строка после заголовка – '
        f'«Старый чат: {sid}» (по ней новый чат сам переименует этот в «-»); дальше: цель, что сделано со ссылками и коммитами, '
        'что в работе и на каком шаге, что ждёт владельца, правила и решения этого чата, пути к файлам и репо; '
        '2) если в проекте есть файл состояния (docs/sostoyanie.md и т. п.) – строка туда и коммит; '
        '3) ответ: где выжимка и строка для нового чата «Продолжаем <тема>: прочитай ~/.claude/vyzhimki/<файл>» и фраза '
        '«этот чат станет «-», когда откроешь новый». Этот чат сам не переименовывай: открытый чат затрёт название.'
    )
sys.exit(0)
