#!/usr/bin/env python3
"""Маяк толстого чата (правило владельца 15.11.2026): «когда чат разжирается – маякуешь в этом чате, что надо переезжать».

Хук UserPromptSubmit. Модель не зовёт и токены не тратит: читает хвост файла сессии, берёт размер
контекста последнего шага. Если больше 300 тыс. – подсказывает Claude первой строкой ответа
сказать тебе, что пора переезжать. Повторяет на 300, 400, 500… тыс. (не на каждом сообщении).
Отметки – ~/.claude/hooks/state/mayak-<сессия>.
Порядок переезда – скилл ~/.claude/skills/pereezd, переименование старого чата в «-» – хук pereezd.py (19.11).
Проверка: echo '{"transcript_path":"<файл>.jsonl","session_id":"x"}' | python3 этот_файл
"""
import json
import os
import sys

POROG = 300_000
SHAG = 100_000

try:
    vhod = json.load(sys.stdin)
    put = vhod.get('transcript_path') or ''
    sid = (vhod.get('session_id') or os.path.basename(put))[:36]
    with open(put, 'rb') as f:
        f.seek(0, 2)
        f.seek(max(0, f.tell() - 400_000))
        hvost = f.read().decode('utf-8', 'ignore').splitlines()
except Exception:
    sys.exit(0)

ctx = 0
for line in reversed(hvost):
    if '"usage"' not in line:
        continue
    try:
        d = json.loads(line)
    except ValueError:
        continue
    if d.get('isSidechain'):
        continue
    u = (d.get('message') or {}).get('usage') or {}
    ctx = u.get('input_tokens', 0) + u.get('cache_read_input_tokens', 0) + u.get('cache_creation_input_tokens', 0)
    if ctx:
        break

if ctx < POROG:
    sys.exit(0)

stupen = ctx // SHAG
papka = os.path.expanduser('~/.claude/hooks/state')
os.makedirs(papka, exist_ok=True)
otm = os.path.join(papka, f'mayak-{sid}')
try:
    byla = int(open(otm).read().strip() or 0)
except Exception:
    byla = 0
if stupen <= byla:
    sys.exit(0)
open(otm, 'w').write(str(stupen))

tys = ctx // 1000
print(json.dumps({'hookSpecificOutput': {
    'hookEventName': 'UserPromptSubmit',
    'additionalContext': (
        f'МАЯК ТОЛСТОГО ЧАТА: контекст этого чата {tys} тыс. токенов на шаг (порог 300 тыс.). '
        'Первой строкой ответа скажи тебе: «⚠️ Чат разжирел: ' + str(tys) + ' тыс. на шаг – каждый шаг дорогой. '
        'Пора переезжать: напиши «переезд» – соберу выжимку и строку для нового чата.» Потом отвечай как обычно. '
        'Новых фоновых агентов из этого чата без нужды не запускай: каждый вернувшийся агент – ещё ход на весь контекст. '
        'Когда владелец скажет «переезд» – порядок в скилле pereezd (хук pereezd.py подскажет его с id чата): выжимка '
        f'с первой строкой «Старый чат: {sid}», строка для нового чата; этот чат станет «-», когда откроют новый.'
    )}}, ensure_ascii=False))
