#!/usr/bin/env python3
"""Переименовать чат Claude Code (правило владельца 19.11.2026: «чат, с которого переезжаем, переименовывается на -»).

Делает то же, что /rename: дописывает в файл сессии строку {"type":"custom-title",...}
и пишет <папка сессии>/custom-title.json. Так владелец переименовал прошлый чат дизайна
Evolution Минск (8f975cc2, «EV Сер М Прототип» → «-», 18.11).

Важно: ОТКРЫТЫЙ чат после каждого своего хода заново дописывает своё название
(в 4c199bcb одно /rename дало 8 строк custom-title). Поэтому старый чат переименовывает
НОВЫЙ чат – хук ~/.claude/hooks/pereezd.py, когда в новом чате открыли выжимку.

Запуск: pereezd-pereimenovat.py <id сессии или начало id> [название, по умолчанию «-»] [--koren <папка projects>]
Код: 0 – переименован или уже был с этим названием, 1 – сессия не найдена или найдено несколько.
"""
import glob
import json
import os
import sys

KOREN = os.path.expanduser('~/.claude/projects')


def nayti(sid, koren=KOREN):
    """Файлы сессии верхнего уровня (не subagents) по полному id или его началу."""
    # <projects>/<проект>/<id>.jsonl; файлы агентов лежат глубже (<id>/subagents/) и сюда не попадают
    return glob.glob(os.path.join(koren, '*', sid + '*.jsonl')) if len(sid) >= 8 else []


def tekushchee(put):
    """Последнее название из файла сессии (или пусто)."""
    nazv = ''
    try:
        with open(put, 'rb') as f:
            f.seek(0, 2)
            f.seek(max(0, f.tell() - 2_000_000))
            for line in f.read().decode('utf-8', 'ignore').splitlines():
                if '"custom-title"' in line:
                    try:
                        nazv = json.loads(line).get('customTitle', nazv)
                    except ValueError:
                        pass
    except OSError:
        pass
    return nazv


def pereimenovat(sid, nazv='-', koren=KOREN):
    """Возвращает (код, текст). Код 0 – готово или уже так, 1 – не найдено/неоднозначно."""
    faily = nayti(sid, koren)
    if len(faily) != 1:
        return 1, f'сессия {sid}: найдено файлов {len(faily)}, нужен ровно один'
    put = faily[0]
    polnyy = os.path.basename(put)[:-6]
    bylo = tekushchee(put)
    if bylo == nazv:
        return 0, f'чат {polnyy[:8]} уже называется «{nazv}»'
    zapis = json.dumps({'type': 'custom-title', 'customTitle': nazv, 'sessionId': polnyy},
                       ensure_ascii=False, separators=(',', ':'))
    with open(put, 'a', encoding='utf-8') as f:
        f.write(zapis + '\n')
    papka = put[:-6]
    os.makedirs(papka, exist_ok=True)
    with open(os.path.join(papka, 'custom-title.json'), 'w', encoding='utf-8') as f:
        f.write(json.dumps({'customTitle': nazv}, ensure_ascii=False, separators=(',', ':')))
    return 0, f'чат {polnyy[:8]} «{bylo or "без названия"}» → «{nazv}»'


if __name__ == '__main__':
    args = sys.argv[1:]
    koren = KOREN
    if '--koren' in args:
        i = args.index('--koren')
        koren = args[i + 1]
        del args[i:i + 2]
    if not args:
        print(__doc__)
        sys.exit(1)
    kod, tekst = pereimenovat(args[0], args[1] if len(args) > 1 else '-', koren)
    print(tekst)
    sys.exit(kod)
